package me.saidur.movietune.fragments;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;

import java.util.List;

import me.saidur.movietune.R;
import me.saidur.movietune.adapter.MoviesAdapter;
import me.saidur.movietune.model.Movie;
import me.saidur.movietune.model.MovieDetailsResponse;
import me.saidur.movietune.model.MoviesResponse;
import me.saidur.movietune.model.SpokenLanguage;
import me.saidur.movietune.rest.ApiClient;
import me.saidur.movietune.rest.ApiInterface;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class TopRated extends Fragment {

    private static final String TAG = NewRelease.class.getSimpleName();

    // Inset your themoviedb.org api key
    private final static String API_KEY = "c37d3b40004717511adb2c1fbb15eda4";
    ApiInterface apiService;
    RecyclerView recyclerView;

    public TopRated() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Logger.addLogAdapter(new AndroidLogAdapter());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_top_rated, container, false);

        if (API_KEY.isEmpty()) {
            Toast.makeText(getContext(), "Please obtain your API KEY from themoviedb.org first!", Toast.LENGTH_LONG).show();
            return null;
        }

        recyclerView = (RecyclerView) v.findViewById(R.id.movies_recycler_view);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));

        apiService = ApiClient.getClient().create(ApiInterface.class);

        topRatedMoviesFunction();
        //topRatedMovieDetailsFunction();

        return v;
    }

    private void topRatedMoviesFunction() {

        Call<MoviesResponse> call1 = apiService.getTopRatedMovies(API_KEY);
        call1.enqueue(new Callback<MoviesResponse>() {
            @Override
            public void onResponse(Call<MoviesResponse> call, Response<MoviesResponse> response) {
                int statusCode = response.code();
                List<Movie> movies = response.body().getResults();
                recyclerView.setAdapter(new MoviesAdapter(movies, R.layout.list_item_movie, getContext()));
            }

            @Override
            public void onFailure(Call<MoviesResponse> call, Throwable t) {
                // Log error here since request failed
                Logger.d(TAG, t.toString());
            }
        });
    }

    /*private void topRatedMovieDetailsFunction() {
        Call<MovieDetailsResponse> call = apiService.getMovieDetails(id,API_KEY);
        call.enqueue(new Callback<MovieDetailsResponse>() {
            @Override
            public void onResponse(Call<MovieDetailsResponse> call, Response<MovieDetailsResponse> response) {
                int statusCode = response.code();
                List<SpokenLanguage> spokenLanguages = response.body().getSpokenLanguages();
                //recyclerView.setAdapter(new MoviesAdapter(movies, R.layout.list_item_movie, getContext()));
            }

            @Override
            public void onFailure(Call<MovieDetailsResponse> call, Throwable t) {
                // Log error here since request failed
                Logger.d(TAG, t.toString());
            }
        });
    }*/



    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}
