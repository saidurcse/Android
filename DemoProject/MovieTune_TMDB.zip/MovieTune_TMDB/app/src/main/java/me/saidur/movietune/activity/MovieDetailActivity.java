package me.saidur.movietune.activity;

import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;
import com.squareup.picasso.Picasso;

import java.util.List;

import me.saidur.movietune.R;
import me.saidur.movietune.adapter.MoviesDetailsAdapter;
import me.saidur.movietune.adapter.MoviesDetailsCountryAdapter;
import me.saidur.movietune.fragments.NewRelease;
import me.saidur.movietune.model.Movie;
import me.saidur.movietune.model.MovieDetailsResponse;
import me.saidur.movietune.model.ProductionCountry;
import me.saidur.movietune.model.SpokenLanguage;
import me.saidur.movietune.rest.ApiClient;
import me.saidur.movietune.rest.ApiInterface;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MovieDetailActivity extends AppCompatActivity {

    private static final String TAG = NewRelease.class.getSimpleName();

    public static final String EXTRA_MOVIE = "movie";

    // TODO - insert your themoviedb.org API KEY here
    private final static String API_KEY = "c37d3b40004717511adb2c1fbb15eda4";

    private Movie mMovie;
    List<SpokenLanguage> spokenLanguages;
    List<ProductionCountry> productionCountries;
    RecyclerView recyclerView;
    /*ImageView backdropPath;
    ImageView posterPath;
    TextView title;
    TextView overview;
    TextView voteCount;*/
    TextView showId;
    TextView showLang;
    Integer id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
        Logger.addLogAdapter(new AndroidLogAdapter());

        if (getIntent().hasExtra(EXTRA_MOVIE)) {
            mMovie = getIntent().getParcelableExtra(EXTRA_MOVIE);
        } else {
            throw new IllegalArgumentException("Detail activity must receive a movie parcelable");
        }

        if (API_KEY.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please obtain your API KEY first from themoviedb.org", Toast.LENGTH_LONG).show();
            return;
        }

        /*Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        CollapsingToolbarLayout toolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.toolbar_layout);
        toolbarLayout.setTitle(mMovie.getTitle());*/

        /*backdropPath = (ImageView) findViewById(R.id.backdrop);
        title = (TextView) findViewById(R.id.movie_title);
        overview = (TextView) findViewById(R.id.movie_description);
        posterPath = (ImageView) findViewById(R.id.movie_poster);
        voteCount = (TextView) findViewById(R.id.voteCount);
        showId = (TextView)  findViewById(R.id.movieId);

        title.setText(mMovie.getTitle());
        overview.setText(mMovie.getOverview());
        Picasso.with(this)
                .load(mMovie.getPosterPath())
                .into(posterPath);
        Picasso.with(this)
                .load(mMovie.getBackdropPath())
                .into(backdropPath);

        voteCount.setText(String.valueOf(mMovie.getVoteCount()));
        showId.setText(String.valueOf(mMovie.getId()));*/


        recyclerView = (RecyclerView) findViewById(R.id.movies_details_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        id = mMovie.getId();
        ApiInterface apiService = ApiClient.getClient().create(ApiInterface.class);

        Call<MovieDetailsResponse> callLang = apiService.getMovieDetails(id, API_KEY);
        callLang.enqueue(new Callback<MovieDetailsResponse>() {
            @Override
            public void onResponse(Call<MovieDetailsResponse> call, Response<MovieDetailsResponse> response) {
                spokenLanguages = response.body().getSpokenLanguages();
                Logger.d(TAG, spokenLanguages.toString());
                recyclerView.setAdapter(new MoviesDetailsAdapter(spokenLanguages, R.layout.test_list_item_movie, getApplicationContext()));
            }

            @Override
            public void onFailure(Call<MovieDetailsResponse> call, Throwable t) {
                // Log error here since request failed
                Logger.d(TAG, t.toString());
            }
        });

        Call<MovieDetailsResponse> callCountry = apiService.getMovieDetails(id, API_KEY);
        callCountry.enqueue(new Callback<MovieDetailsResponse>() {
            @Override
            public void onResponse(Call<MovieDetailsResponse> call, Response<MovieDetailsResponse> response) {
                productionCountries = response.body().getProductionCountries();
                Logger.d(TAG, productionCountries.toString());
                recyclerView.setAdapter(new MoviesDetailsCountryAdapter(productionCountries, R.layout.test_list_item_movie, getApplicationContext()));
            }

            @Override
            public void onFailure(Call<MovieDetailsResponse> call, Throwable t) {
                // Log error here since request failed
                Logger.d(TAG, t.toString());
            }
        });

    }
}
