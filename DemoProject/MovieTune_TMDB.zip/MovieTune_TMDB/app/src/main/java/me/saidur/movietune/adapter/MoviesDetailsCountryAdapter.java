package me.saidur.movietune.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import me.saidur.movietune.R;
import me.saidur.movietune.model.ProductionCountry;
import me.saidur.movietune.model.SpokenLanguage;


public class MoviesDetailsCountryAdapter extends RecyclerView.Adapter<MoviesDetailsCountryAdapter.MovieViewHolder> {

    private static final String TAG = MoviesDetailsCountryAdapter.class.getSimpleName();

    private List<ProductionCountry> productionCountries;
    private int rowLayout;
    private Context context;

/*     public MoviesDetailsCountryAdapter(List<ProductionCountry> productionCountries, int test_list_item_movie, Context applicationContext) {
        this.productionCountries = productionCountries;
        this.rowLayout = test_list_item_movie;
        this.context = applicationContext;
    }*/

    public MoviesDetailsCountryAdapter(List<ProductionCountry> productionCountries, int rowLayout, Context context) {
        this.productionCountries = productionCountries;
        this.rowLayout = rowLayout;
        this.context = context;
    }


    public static class MovieViewHolder extends RecyclerView.ViewHolder {
        TextView country;
        //TextView movieTitle;
        //TextView data;
        //TextView movieDescription;
        //TextView rating;


        public MovieViewHolder(View v) {
            super(v);
            country= (TextView) v.findViewById(R.id.country);
            //moviesLayout = (LinearLayout) v.findViewById(R.id.movies_layout);
            //movieTitle = (TextView) v.findViewById(R.id.title);
            //data = (TextView) v.findViewById(R.id.subtitle);
            //movieDescription = (TextView) v.findViewById(R.id.description);
            //rating = (TextView) v.findViewById(R.id.rating);
        }
    }

    @Override
    public MoviesDetailsCountryAdapter.MovieViewHolder onCreateViewHolder(ViewGroup parent, final int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(rowLayout, parent, false);

        final MovieViewHolder viewHolder = new MovieViewHolder(view);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int position = viewHolder.getAdapterPosition();
                //Intent intent = new Intent(context, MovieDetailActivity.class);
                //intent.putExtra(MovieDetailActivity.EXTRA_MOVIE, movies.get(position));
                //context.startActivity(intent);
            }
        });

        //return new MovieViewHolder(view);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(MovieViewHolder holder, int position) {
        holder.country.setText(productionCountries.get(position).getName());
        //Picasso.with(context)
                //.load(movie.getPosterPath())
                //.placeholder(R.color.colorAccent)
                //.into(holder.imageView);
        //holder.movieTitle.setText(movies.get(position).getTitle());
        //holder.data.setText(movies.get(position).getReleaseDate());
        //holder.movieDescription.setText(movies.get(position).getOverview());
        //holder.rating.setText(movies.get(position).getVoteAverage().toString());
    }

    @Override
    public int getItemCount() {
        //Log.d(TAG, movies.size() + " movie size");
        return (productionCountries == null) ? 0 : productionCountries.size();
    }
}